"""Server-side components for implementing an A2A agent."""
